import multiprocessing

__author__ = "Niko Heeren"
__copyright__ = "Copyright 2018"
__credits__ = ["Niko Heeren", "Rupert Myers"]
__license__ = "TBA"
__version__ = "0.0"
__maintainer__ = "Niko Heeren"
__email__ = "niko.heeren@gmail.com"
__status__ = "raw"

"""
Project-wide settings and variables go here.
"""

### Inputs

# the file where the inputs like distributions and classifications are loaded from
input_file = '../data/input.xlsx'
input_file = '../data/input_validation.xlsx'
# the sheet on the input file for (5) binder classifications
binder_slassification_sheet = '5_binder_classification'

inert_oxides = ['K2O', 'Na2O', 'CO2']
non_inert_oxides = ['CaO', 'SiO2', 'Al2O3', 'Fe2O3', 'MgO', 'SO3']


### Runtime

temp_folder = '../temp/'
temp_folder = '../out_valid/'
sampling_method = 'random'  # the other option is 'random'
random_samples = 2500  # number of random samples
# grid_resolution = 1.0  # resolution for grid sampling
cpus = max(1, multiprocessing.cpu_count() - 2)  # number of CPUs to use
