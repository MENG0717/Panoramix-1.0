"""
Functions to visualize things
"""

import os

from panoramix import *
import matplotlib.pyplot as plt
# import ternary


def hist_oxide_mix_samples(samples):
    """
    Uses the samples from (1) / `sample_oxide_mix_4a_sm()` to plot histograms
    :param samples:
    """
    folder = os.path.join(settings.temp_folder, '1_oxide_samples_histograms/')
    if not os.path.exists(folder):
        os.makedirs(folder)
    for raw_mat in tqdm(samples.columns.levels[0], unit='figure'):
        plt.figure()
        samples.loc[:, raw_mat].loc[:, (samples.loc[:, raw_mat]).any(axis=0)]\
            .hist(sharex=True, bins=50, range=(0, 1), figsize=(8, 8))
        plt.savefig(folder + raw_mat + '.png')
        plt.close()


def hist_raw_material_samples(samples):
    """
    Uses the samples from (1) / `sample_oxide_mix_4a_sm()` to plot histograms
    :param samples:
    """
    plt.figure()
    samples.loc[:, samples.any(axis=0)].hist(figsize=(8, 8))
    plt.savefig(os.path.join(settings.temp_folder, '2_raw_material_samples_histogram.png'))
    plt.close()


def pie_classifications(classified):
    print("5 - plotting")
    folder = os.path.join(settings.temp_folder, '5_classified/')
    if not os.path.exists(folder):
        os.makedirs(folder)
    for c in classified.columns:
        classified[c].value_counts().plot.pie()
        plt.savefig(os.path.join(folder, str(c).replace('/', '_') + '.png'))


def ternary_scatter(plot_data):
    scale = 80
    figure, tax = ternary.figure(scale=scale)
    figure.set_size_inches(10, 10)
    # Plot a few different styles with a legend
    plot_me = plot_data.loc[:, ['Al2O3', 'CaO', 'SO3']].values
    tax.scatter(plot_me,
                marker='s', color='red', label="Red Squares")

    tax.legend()

    tax.set_title("Scatter Plot", fontsize=20)
    tax.boundary(linewidth=2.0)
    tax.gridlines(multiple=5, color="blue")
    tax.ticks(axis='lbr', linewidth=1, multiple=5)
    tax.clear_matplotlib_ticks()
    tax.get_axes().axis('off')

    tax.show()
    tax.savefig(os.path.join(settings.temp_folder, '11_scatter.pdf'))
