# Panoramix

:unicorn: This is the first iteration of a biogeochemical and environmental simulation platform for cementitious and non-cementitious concrete.

## Content

- [Model documentation](./doc/documentation.md)

