"""
This is the main code routine.
"""

from panoramix import *

pass

