# ToDos

Keeping track of open ToDos

## Open

- [ ] Solve sampling routine issue (see `notes.md`)
  - [ ] copy the code from `sandbox.py` to a jupyter notebook and plot the distributions to figure out if this does what I want...
- [ ] Implement water and CaSO4 normalisation, based on sampled mass of main materials. This is currently *not* reflected in `dummy_tables_4.xlsx`. More info in the Overleaf manuscript draft.
- [ ] Use https://github.com/marcharper/python-ternary

## Done
